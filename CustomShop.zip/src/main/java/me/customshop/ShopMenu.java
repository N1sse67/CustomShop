package me.customshop;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * Меню-сундук (для Java-игроков и для Bedrock, если они выбрали этот вид).
 * Меню перерисовывается на месте после каждой покупки/продажи, поэтому баланс всегда свежий.
 */
public final class ShopMenu implements InventoryHolder {

    private static final int PAGE_SIZE = 45;

    private final ShopPlugin plugin;
    private final Player viewer;
    private final ShopManager.Category category; // null = главное меню
    private final Map<Integer, BiConsumer<Player, ClickType>> actions = new HashMap<>();
    private final Inventory inventory;
    private final int rows;
    private int page;
    private boolean sellMode;

    // Меню выбора количества (как в EconomyShopGUI): detail != null
    private ShopManager.Item detail;
    private int qty = 1;
    private int returnPage;

    private ShopMenu(ShopPlugin plugin, Player viewer, ShopManager.Category category, Component title, int rows) {
        this.plugin = plugin;
        this.viewer = viewer;
        this.category = category;
        this.rows = rows;
        this.inventory = Bukkit.createInventory(this, rows * 9, title);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public BiConsumer<Player, ClickType> actionAt(int slot) {
        return actions.get(slot);
    }

    private void set(int slot, ItemStack stack, BiConsumer<Player, ClickType> action) {
        inventory.setItem(slot, stack);
        if (action != null) actions.put(slot, action);
    }

    private static ItemStack button(Material material, String name) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(ShopPlugin.text(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    // ---------- открытие ----------

    public static void openMain(ShopPlugin plugin, Player player) {
        int count = plugin.shop().categories().size();
        int configured = plugin.getConfig().getInt("main-menu-rows", 6);
        int needed = Math.min(6, (count + 6) / 7 + 2);
        int rows = Math.min(6, Math.max(3, Math.max(configured, needed)));
        ShopMenu menu = new ShopMenu(plugin, player, null, ShopPlugin.title(plugin.raw("main-title")), rows);
        menu.render();
        player.openInventory(menu.getInventory());
    }

    public static void openCategory(ShopPlugin plugin, Player player, ShopManager.Category cat, int page) {
        Component title = ShopPlugin.title(plugin.raw("category-title").replace("%category%", cat.name));
        ShopMenu menu = new ShopMenu(plugin, player, cat, title, 6);
        menu.page = page;
        menu.render();
        player.openInventory(menu.getInventory());
    }

    /** Меню выбора количества для одного предмета. sell=true: продажа, иначе покупка. */
    public static void openDetail(ShopPlugin plugin, Player player, ShopManager.Category cat,
                                  ShopManager.Item item, boolean sell, int returnPage) {
        Component title = ShopPlugin.title(item.displayName());
        ShopMenu menu = new ShopMenu(plugin, player, cat, title, 3);
        menu.detail = item;
        menu.sellMode = sell;
        menu.returnPage = returnPage;
        menu.qty = 1;
        menu.render();
        player.openInventory(menu.getInventory());
    }

    public static void openCategory(ShopPlugin plugin, Player player, ShopManager.Category cat, int page, boolean sell) {
        Component title = ShopPlugin.title(plugin.raw("category-title").replace("%category%", cat.name));
        ShopMenu menu = new ShopMenu(plugin, player, cat, title, 6);
        menu.page = page;
        menu.sellMode = sell;
        menu.render();
        player.openInventory(menu.getInventory());
    }

    // ---------- отрисовка ----------

    private void render() {
        inventory.clear();
        actions.clear();
        if (category == null) {
            renderMain();
        } else if (detail != null) {
            renderDetail();
        } else {
            renderCategory();
        }
    }

    private void renderMain() {
        List<ShopManager.Category> cats = new ArrayList<>(plugin.shop().categories());
        int bottom = (rows - 1) * 9;

        // Категории стоят рядами по 7 с отступом от краёв; если их слишком много, идут подряд с первой ячейки.
        boolean spaced = cats.size() <= (rows - 2) * 7;
        for (int i = 0; i < cats.size(); i++) {
            int slot = spaced ? (1 + i / 7) * 9 + 1 + i % 7 : i;
            if (slot >= bottom) break;
            ShopManager.Category cat = cats.get(i);
            set(slot, button(cat.icon, cat.name), (p, click) -> openCategory(plugin, p, cat, 0));
        }

        set(bottom + 4, button(Material.GOLD_INGOT, plugin.balanceText(viewer, "balance-item")), null);
        if (plugin.isBedrock(viewer)) {
            set(bottom + 8, button(Material.COMPARATOR, plugin.raw("button-mode")), (p, click) -> plugin.toggleMode(p));
        }
    }

    private void renderCategory() {
        ShopManager shop = plugin.shop();

        List<ShopManager.Item> visible = new ArrayList<>();
        boolean anySellable = false;
        for (ShopManager.Item item : category.items) {
            if (shop.canSell(item)) anySellable = true;
            if (!sellMode || shop.canSell(item)) visible.add(item);
        }
        if (page > 0 && page * PAGE_SIZE >= visible.size()) page = 0;

        int from = page * PAGE_SIZE;
        for (int i = 0; i < PAGE_SIZE && from + i < visible.size(); i++) {
            ShopManager.Item item = visible.get(from + i);
            if (sellMode) {
                set(i, shop.buildSellStack(item, viewer),
                        (p, click) -> openDetail(plugin, p, category, item, true, page));
            } else {
                set(i, shop.buildStack(item, true),
                        (p, click) -> openDetail(plugin, p, category, item, false, page));
            }
        }
        if (visible.isEmpty()) {
            set(22, button(Material.PAPER, plugin.raw("category-empty")), null);
        }

        if (page > 0) {
            set(45, button(Material.ARROW, plugin.raw("button-prev")), (p, click) -> {
                page--;
                render();
            });
        }
        if (anySellable) {
            String name = plugin.raw(sellMode ? "button-mode-sell" : "button-mode-buy");
            set(46, button(sellMode ? Material.EMERALD : Material.CHEST, name), (p, click) -> {
                sellMode = !sellMode;
                page = 0;
                render();
            });
        }
        if (plugin.isBedrock(viewer)) {
            set(47, button(Material.COMPARATOR, plugin.raw("button-mode")), (p, click) -> plugin.toggleMode(p));
        }
        set(49, button(Material.BARRIER, plugin.raw("button-back")), (p, click) -> openMain(plugin, p));
        set(51, button(Material.GOLD_INGOT, plugin.balanceText(viewer, "balance-item")), null);
        if (from + PAGE_SIZE < visible.size()) {
            set(53, button(Material.ARROW, plugin.raw("button-next")), (p, click) -> {
                page++;
                render();
            });
        }
    }

    // ---------- выбор количества ----------

    private int maxQty() {
        return plugin.shop().maxQuantity(detail);
    }

    private int haveCount() {
        return plugin.shop().count(viewer, detail);
    }

    private int maxAllowed() {
        return sellMode ? Math.max(1, Math.min(plugin.shop().maxSellQuantity(), haveCount())) : maxQty();
    }

    private void changeQty(int delta) {
        qty = Math.max(1, Math.min(maxAllowed(), qty + delta));
        render();
    }

    private ItemStack qtyButton(Material material, String name, int amount) {
        ItemStack stack = button(material, name);
        stack.setAmount(Math.max(1, Math.min(64, amount)));
        return stack;
    }

    private void renderDetail() {
        ShopManager shop = plugin.shop();
        ShopManager.Item item = detail;
        if (qty > maxAllowed()) qty = maxAllowed();

        double total = (sellMode ? item.sellPrice : item.price) * qty;

        // Сам предмет в центре с количеством и итоговой ценой.
        ItemStack shown = shop.buildStack(item, false);
        int perPortion = Math.max(1, shown.getAmount());
        shown.setAmount(Math.max(1, Math.min(shown.getMaxStackSize(), sellMode ? qty : perPortion * qty)));
        ItemMeta meta = shown.getItemMeta();
        if (meta != null) {
            List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
            lore.add(Component.empty());
            int pieces = sellMode ? qty : perPortion * qty;
            lore.add(ShopPlugin.text(plugin.raw("qty-lore").replace("%count%", String.valueOf(pieces))));
            lore.add(ShopPlugin.text(plugin.raw(sellMode ? "total-sell-lore" : "total-lore")
                    .replace("%price%", shop.priceText(total))));
            if (sellMode) {
                lore.add(ShopPlugin.text(plugin.raw("have-lore").replace("%count%", String.valueOf(haveCount()))));
            }
            meta.lore(lore);
            if (!item.label.isEmpty() && item.name.isEmpty() && item.template == null) {
                meta.displayName(ShopPlugin.text(item.label));
            }
            shown.setItemMeta(meta);
        }
        set(13, shown, null);

        // Уменьшить / увеличить
        int[] steps = {64, 16, 8, 1};
        for (int i = 0; i < steps.length; i++) {
            int step = steps[i];
            set(9 + i, qtyButton(Material.RED_STAINED_GLASS_PANE, "&c-" + step, step), (p, click) -> changeQty(-step));
            set(17 - i, qtyButton(Material.LIME_STAINED_GLASS_PANE, "&a+" + step, step), (p, click) -> changeQty(step));
        }

        // Нижний ряд
        set(18, button(Material.ARROW, plugin.raw("button-back")),
                (p, click) -> openCategory(plugin, p, category, returnPage, sellMode));

        set(20, button(Material.PAPER, plugin.raw("button-qty-reset")), (p, click) -> {
            qty = 1;
            render();
        });

        String confirmName = sellMode
                ? plugin.raw("button-sell-qty").replace("%count%", String.valueOf(qty)).replace("%price%", shop.priceText(total))
                : plugin.raw("button-buy-qty").replace("%count%", String.valueOf(qty)).replace("%price%", shop.priceText(total));
        set(22, button(sellMode ? Material.EMERALD_BLOCK : Material.LIME_CONCRETE, confirmName), (p, click) -> {
            if (sellMode) shop.sell(p, item, qty); else shop.buy(p, item, qty);
            render();
        });

        set(24, button(Material.HOPPER, plugin.raw("button-qty-max")), (p, click) -> {
            if (sellMode) {
                qty = maxAllowed();
            } else {
                VaultEconomy eco = plugin.economy();
                int affordable = 1;
                if (eco != null && item.price > 0) {
                    affordable = (int) Math.min(maxQty(), Math.floor((eco.balance(p) + 1e-9) / item.price));
                }
                qty = Math.max(1, affordable);
            }
            render();
        });

        if (shop.canSell(item)) {
            String name = plugin.raw(sellMode ? "button-mode-sell" : "button-mode-buy");
            set(25, button(sellMode ? Material.EMERALD : Material.CHEST, name), (p, click) -> {
                sellMode = !sellMode;
                qty = 1;
                render();
            });
        }
        set(26, button(Material.GOLD_INGOT, plugin.balanceText(viewer, "balance-item")), null);
    }
}
