package me.customshop;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * Меню-сундук (для Java-игроков и для Bedrock, если они выбрали этот вид).
 * Меню перерисовывается на месте после каждой покупки/продажи, поэтому баланс всегда свежий.
 */
public final class ShopMenu implements InventoryHolder {

    private static final int PAGE_SIZE = 45;

    private final ShopPlugin plugin;
    private final Player viewer;
    private final ShopManager.Category category; // null = главное меню
    private final Map<Integer, BiConsumer<Player, ClickType>> actions = new HashMap<>();
    private final Inventory inventory;
    private final int rows;
    private int page;
    private boolean sellMode;

    private ShopMenu(ShopPlugin plugin, Player viewer, ShopManager.Category category, Component title, int rows) {
        this.plugin = plugin;
        this.viewer = viewer;
        this.category = category;
        this.rows = rows;
        this.inventory = Bukkit.createInventory(this, rows * 9, title);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public BiConsumer<Player, ClickType> actionAt(int slot) {
        return actions.get(slot);
    }

    private void set(int slot, ItemStack stack, BiConsumer<Player, ClickType> action) {
        inventory.setItem(slot, stack);
        if (action != null) actions.put(slot, action);
    }

    private static ItemStack button(Material material, String name) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(ShopPlugin.text(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    // ---------- открытие ----------

    public static void openMain(ShopPlugin plugin, Player player) {
        int count = plugin.shop().categories().size();
        int rows = Math.min(6, Math.max(3, (count + 8) / 9 + 1));
        ShopMenu menu = new ShopMenu(plugin, player, null, ShopPlugin.title(plugin.raw("main-title")), rows);
        menu.render();
        player.openInventory(menu.getInventory());
    }

    public static void openCategory(ShopPlugin plugin, Player player, ShopManager.Category cat, int page) {
        Component title = ShopPlugin.title(plugin.raw("category-title").replace("%category%", cat.name));
        ShopMenu menu = new ShopMenu(plugin, player, cat, title, 6);
        menu.page = page;
        menu.render();
        player.openInventory(menu.getInventory());
    }

    // ---------- отрисовка ----------

    private void render() {
        inventory.clear();
        actions.clear();
        if (category == null) {
            renderMain();
        } else {
            renderCategory();
        }
    }

    private void renderMain() {
        List<ShopManager.Category> cats = new ArrayList<>(plugin.shop().categories());
        int limit = (rows - 1) * 9;
        for (int i = 0; i < cats.size() && i < limit; i++) {
            ShopManager.Category cat = cats.get(i);
            set(i, button(cat.icon, cat.name), (p, click) -> openCategory(plugin, p, cat, 0));
        }

        int bottom = (rows - 1) * 9;
        set(bottom + 4, button(Material.GOLD_INGOT, plugin.balanceText(viewer, "balance-item")), null);
        if (plugin.isBedrock(viewer)) {
            set(bottom + 8, button(Material.COMPARATOR, plugin.raw("button-mode")), (p, click) -> plugin.toggleMode(p));
        }
    }

    private void renderCategory() {
        ShopManager shop = plugin.shop();

        List<ShopManager.Item> visible = new ArrayList<>();
        boolean anySellable = false;
        for (ShopManager.Item item : category.items) {
            if (shop.canSell(item)) anySellable = true;
            if (!sellMode || shop.canSell(item)) visible.add(item);
        }
        if (page > 0 && page * PAGE_SIZE >= visible.size()) page = 0;

        int from = page * PAGE_SIZE;
        for (int i = 0; i < PAGE_SIZE && from + i < visible.size(); i++) {
            ShopManager.Item item = visible.get(from + i);
            if (sellMode) {
                set(i, shop.buildSellStack(item, viewer), (p, click) -> {
                    shop.sell(p, item, click.isRightClick() || click.isShiftClick());
                    render();
                });
            } else {
                set(i, shop.buildStack(item, true), (p, click) -> {
                    shop.buy(p, item);
                    render();
                });
            }
        }
        if (visible.isEmpty()) {
            set(22, button(Material.PAPER, plugin.raw("category-empty")), null);
        }

        if (page > 0) {
            set(45, button(Material.ARROW, plugin.raw("button-prev")), (p, click) -> {
                page--;
                render();
            });
        }
        if (anySellable) {
            String name = plugin.raw(sellMode ? "button-mode-sell" : "button-mode-buy");
            set(46, button(sellMode ? Material.EMERALD : Material.CHEST, name), (p, click) -> {
                sellMode = !sellMode;
                page = 0;
                render();
            });
        }
        if (plugin.isBedrock(viewer)) {
            set(47, button(Material.COMPARATOR, plugin.raw("button-mode")), (p, click) -> plugin.toggleMode(p));
        }
        set(49, button(Material.BARRIER, plugin.raw("button-back")), (p, click) -> openMain(plugin, p));
        set(51, button(Material.GOLD_INGOT, plugin.balanceText(viewer, "balance-item")), null);
        if (from + PAGE_SIZE < visible.size()) {
            set(53, button(Material.ARROW, plugin.raw("button-next")), (p, click) -> {
                page++;
                render();
            });
        }
    }
}
