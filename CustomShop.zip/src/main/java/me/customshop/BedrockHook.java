package me.customshop;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Формы для игроков с Bedrock через Floodgate. Класс загружается только если Floodgate установлен. */
public final class BedrockHook {

    private final ShopPlugin plugin;

    public BedrockHook(ShopPlugin plugin) {
        this.plugin = plugin;
        FloodgateApi.getInstance(); // проверка, что API доступно
    }

    public boolean isBedrock(UUID id) {
        return FloodgateApi.getInstance().isFloodgatePlayer(id);
    }

    /** Формы Bedrock понимают § вместо &. */
    private static String c(String text) {
        return text.replace('&', '§');
    }

    /** Ответ формы приходит не из основного потока сервера, поэтому действия переносим в него. */
    private void sync(Runnable action) {
        Bukkit.getScheduler().runTask(plugin, action);
    }

    // ---------- главное меню ----------

    public void openMain(Player player) {
        List<ShopManager.Category> cats = new ArrayList<>(plugin.shop().categories());

        var form = SimpleForm.builder()
                .title(c(plugin.raw("main-title")))
                .content(c(plugin.balanceText(player, "balance-line")));
        for (ShopManager.Category cat : cats) {
            form.button(c(cat.name));
        }
        form.button(c(plugin.raw("button-mode")));

        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            sync(() -> {
                if (id < cats.size()) {
                    openCategory(player, cats.get(id));
                } else {
                    plugin.toggleMode(player);
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    // ---------- категория ----------

    public void openCategory(Player player, ShopManager.Category cat) {
        ShopManager shop = plugin.shop();
        List<ShopManager.Item> items = cat.items;

        var form = SimpleForm.builder()
                .title(c(cat.name))
                .content(c(plugin.balanceText(player, "balance-line")
                        + (items.isEmpty() ? "\n" + plugin.raw("category-empty") : "")));
        for (ShopManager.Item item : items) {
            String line = c(item.displayName()) + "\n§r§8" + c(shop.priceText(item.price));
            if (shop.canSell(item)) {
                line += c(" §8| " + plugin.raw("sell-short").replace("%price%", shop.priceText(item.sellPrice)));
            }
            form.button(line);
        }
        form.button(c(plugin.raw("button-back")));

        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            sync(() -> {
                if (id < items.size()) {
                    openItem(player, cat, items.get(id));
                } else {
                    openMain(player);
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    // ---------- предмет: купить / продать ----------

    private void openItem(Player player, ShopManager.Category cat, ShopManager.Item item) {
        ShopManager shop = plugin.shop();
        boolean canSell = shop.canSell(item);
        int have = canSell ? shop.count(player, item) : 0;

        StringBuilder text = new StringBuilder();
        for (String line : item.lore) {
            text.append(c(line)).append("\n");
        }
        text.append("\n").append(c(plugin.raw("price-lore").replace("%price%", shop.priceText(item.price))));
        if (canSell) {
            text.append("\n").append(c(plugin.raw("sell-lore").replace("%price%", shop.priceText(item.sellPrice))));
            text.append("\n").append(c(plugin.raw("have-lore").replace("%count%", String.valueOf(have))));
        }
        text.append("\n\n").append(c(plugin.balanceText(player, "balance-line")));

        var form = SimpleForm.builder()
                .title(c(item.displayName()))
                .content(text.toString());

        List<Runnable> actions = new ArrayList<>();
        form.button(c(plugin.raw("button-buy-price").replace("%price%", shop.priceText(item.price))));
        actions.add(() -> shop.buy(player, item));

        if (canSell) {
            form.button(c(plugin.raw("button-sell-one").replace("%price%", shop.priceText(item.sellPrice))));
            actions.add(() -> shop.sell(player, item, false));
            form.button(c(plugin.raw("button-sell-all")
                    .replace("%count%", String.valueOf(have))
                    .replace("%price%", shop.priceText(item.sellPrice * have))));
            actions.add(() -> shop.sell(player, item, true));
        }
        form.button(c(plugin.raw("button-back")));

        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            sync(() -> {
                if (id < actions.size()) {
                    actions.get(id).run();
                    openItem(player, cat, item); // показать обновлённый баланс и количество
                } else {
                    openCategory(player, cat);
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }
}
