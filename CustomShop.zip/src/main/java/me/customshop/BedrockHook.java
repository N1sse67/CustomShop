package me.customshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.cumulus.util.FormImage;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Формы для игроков с Bedrock через Floodgate. Класс загружается только если Floodgate установлен. */
public final class BedrockHook {

    private final ShopPlugin plugin;

    public BedrockHook(ShopPlugin plugin) {
        this.plugin = plugin;
        FloodgateApi.getInstance(); // проверка, что API доступно
    }

    public boolean isBedrock(UUID id) {
        return FloodgateApi.getInstance().isFloodgatePlayer(id);
    }

    /**
     * Формы Bedrock понимают § вместо &. Если в config.yml bedrock-text-black: true,
     * все цвета убираются и текст становится чёрным (§0), иначе цвета остаются как в настройках.
     */
    private String c(String text) {
        String s = text.replace('&', '§');
        if (!plugin.getConfig().getBoolean("bedrock-text-black", true)) return s;
        s = s.replaceAll("(?i)§[0-9a-fr]", "");
        return "§0" + s.replace("\n", "\n§0");
    }

    private static Material materialOf(ShopManager.Item item) {
        if (item.template != null) return item.template.getType();
        return item.giveItem ? item.material : item.icon;
    }

    /** Кнопка с иконкой предмета (картинка по ссылке из config.yml, bedrock-icon-url). */
    private void button(SimpleForm.Builder form, String text, Material material) {
        String url = plugin.getConfig().getString("bedrock-icon-url", "");
        if (material == null || url == null || url.isBlank() || !plugin.getConfig().getBoolean("bedrock-icons", true)) {
            form.button(text);
            return;
        }
        form.button(text, FormImage.Type.URL, url.replace("%material%", material.name().toLowerCase(Locale.ROOT)));
    }

    /** Ответ формы приходит не из основного потока сервера, поэтому действия переносим в него. */
    private void sync(Runnable action) {
        Bukkit.getScheduler().runTask(plugin, action);
    }

    // ---------- главное меню ----------

    public void openMain(Player player) {
        List<ShopManager.Category> cats = new ArrayList<>(plugin.shop().categories());

        var form = SimpleForm.builder()
                .title(c(plugin.raw("main-title")))
                .content(c(plugin.balanceText(player, "balance-line")));
        for (ShopManager.Category cat : cats) {
            button(form, c(cat.name), cat.icon);
        }
        form.button(c(plugin.raw("button-mode")));

        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            sync(() -> {
                if (id < cats.size()) {
                    openCategory(player, cats.get(id));
                } else {
                    plugin.toggleMode(player);
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    // ---------- категория ----------

    public void openCategory(Player player, ShopManager.Category cat) {
        ShopManager shop = plugin.shop();
        List<ShopManager.Item> items = cat.items;

        var form = SimpleForm.builder()
                .title(c(cat.name))
                .content(c(plugin.balanceText(player, "balance-line")
                        + (items.isEmpty() ? "\n" + plugin.raw("category-empty") : "")));
        for (ShopManager.Item item : items) {
            String line = item.displayName() + "\n§r§8" + shop.priceText(item.price);
            if (shop.canSell(item)) {
                line += " §8| " + plugin.raw("sell-short").replace("%price%", shop.priceText(item.sellPrice));
            }
            line = c(line);
            button(form, line, materialOf(item));
        }
        form.button(c(plugin.raw("button-back")));

        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            sync(() -> {
                if (id < items.size()) {
                    openItem(player, cat, items.get(id));
                } else {
                    openMain(player);
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    // ---------- предмет: купить / продать с выбором количества ----------

    private int maxQty(ShopManager.Item item) {
        return plugin.shop().maxQuantity(item);
    }

    private void openItem(Player player, ShopManager.Category cat, ShopManager.Item item) {
        openItem(player, cat, item, 1, false);
    }

    private void openItem(Player player, ShopManager.Category cat, ShopManager.Item item, int qty, boolean sell) {
        ShopManager shop = plugin.shop();
        boolean canSell = shop.canSell(item);
        if (sell && !canSell) sell = false;
        int have = canSell ? shop.count(player, item) : 0;
        if (sell) qty = Math.max(1, Math.min(qty, Math.max(1, Math.min(have, shop.maxSellQuantity()))));
        else qty = Math.max(1, Math.min(maxQty(item), qty));
        final int q = qty;
        final boolean sellMode = sell;
        double total = (sellMode ? item.sellPrice : item.price) * q;

        StringBuilder text = new StringBuilder();
        for (String line : item.lore) {
            text.append(c(line)).append("\n");
        }
        text.append("\n").append(c(plugin.raw("price-lore").replace("%price%", shop.priceText(item.price))));
        if (canSell) {
            text.append("\n").append(c(plugin.raw("sell-lore").replace("%price%", shop.priceText(item.sellPrice))));
            text.append("\n").append(c(plugin.raw("have-lore").replace("%count%", String.valueOf(have))));
        }
        text.append("\n\n").append(c(plugin.raw("qty-lore").replace("%count%", String.valueOf(q))));
        text.append("\n").append(c(plugin.raw(sellMode ? "total-sell-lore" : "total-lore")
                .replace("%price%", shop.priceText(total))));
        text.append("\n\n").append(c(plugin.balanceText(player, "balance-line")));

        var form = SimpleForm.builder()
                .title(c(item.displayName()))
                .content(text.toString());

        List<Runnable> actions = new ArrayList<>();

        // Главная кнопка: подтвердить покупку/продажу выбранного количества.
        String confirm = plugin.raw(sellMode ? "button-sell-qty" : "button-buy-qty")
                .replace("%count%", String.valueOf(q)).replace("%price%", shop.priceText(total));
        button(form, c(confirm), materialOf(item));
        actions.add(() -> {
            if (sellMode) shop.sell(player, item, q); else shop.buy(player, item, q);
            openItem(player, cat, item, q, sellMode);
        });

        int[] steps = {1, 8, 16, 64};
        for (int step : steps) {
            form.button(c("§a+" + step));
            actions.add(() -> openItem(player, cat, item, q + step, sellMode));
        }
        for (int step : steps) {
            form.button(c("§c-" + step));
            actions.add(() -> openItem(player, cat, item, q - step, sellMode));
        }
        form.button(c(plugin.raw("button-qty-reset")));
        actions.add(() -> openItem(player, cat, item, 1, sellMode));

        if (canSell) {
            form.button(c(plugin.raw(sellMode ? "button-mode-sell" : "button-mode-buy")));
            actions.add(() -> openItem(player, cat, item, 1, !sellMode));
        }
        form.button(c(plugin.raw("button-back")));

        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            sync(() -> {
                if (id < actions.size()) {
                    actions.get(id).run();
                } else {
                    openCategory(player, cat);
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }
}
