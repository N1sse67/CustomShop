package me.customshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ShopManager {

    public static final class Item {
        public final String id;
        public final String name;
        public final List<String> lore;
        public final Material material;
        public final Material icon;
        public final int amount;
        public final double price;
        public final Map<String, Integer> enchants;
        public final List<String> commands;
        public final boolean giveItem;
        /** Готовый предмет, сохранённый командой /shop add (со всеми зачарованиями и данными). */
        public final ItemStack template;
        /** Цена продажи за 1 штуку. Отрицательное число (например -1) = продажа запрещена. */
        public final double sellPrice;
        /** Название только для меню и форм; выдаваемый предмет остаётся без этого имени. */
        public final String label;
        /** Тип зелья (например strong_healing) или null. */
        public final String potionType;
        /** Личный лимит порций за раз (0 = автоматически по размеру стака). Поле max-quantity в shop.yml. */
        public int maxQuantity = 0;

        Item(String id, String name, List<String> lore, Material material, Material icon, int amount,
             double price, Map<String, Integer> enchants, List<String> commands, boolean giveItem,
             ItemStack template, double sellPrice, String label, String potionType) {
            this.label = label;
            this.potionType = potionType;
            this.template = template;
            this.sellPrice = sellPrice;
            this.id = id;
            this.name = name;
            this.lore = lore;
            this.material = material;
            this.icon = icon;
            this.amount = amount;
            this.price = price;
            this.enchants = enchants;
            this.commands = commands;
            this.giveItem = giveItem;
        }

        /** Название для сообщений и форм. */
        public String displayName() {
            if (template != null) {
                ItemMeta meta = template.getItemMeta();
                if (meta != null && meta.displayName() != null) {
                    return PlainTextComponentSerializer.plainText().serialize(meta.displayName());
                }
                return template.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
            }
            if (!label.isEmpty()) return label;
            if (!name.isEmpty()) return name;
            Material m = giveItem ? material : icon;
            return m.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        }
    }

    public static final class Category {
        public final String id;
        public final String name;
        public final Material icon;
        public final List<Item> items = new ArrayList<>();

        Category(String id, String name, Material icon) {
            this.id = id;
            this.name = name;
            this.icon = icon;
        }
    }

    private final ShopPlugin plugin;
    private final Map<String, Category> categories = new LinkedHashMap<>();

    public ShopManager(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    public Collection<Category> categories() {
        return categories.values();
    }

    // ---------- загрузка shop.yml ----------

    public void load() {
        categories.clear();
        File file = new File(plugin.getDataFolder(), "shop.yml");
        if (!file.exists()) plugin.saveResource("shop.yml", false);
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection cats = yml.getConfigurationSection("categories");
        if (cats == null) {
            plugin.getLogger().warning("В shop.yml нет раздела categories.");
            return;
        }
        for (String catId : cats.getKeys(false)) {
            ConfigurationSection cs = cats.getConfigurationSection(catId);
            if (cs == null) continue;
            Material icon = material(cs.getString("icon", ""));
            Category cat = new Category(catId, cs.getString("name", catId), icon == null ? Material.CHEST : icon);

            ConfigurationSection items = cs.getConfigurationSection("items");
            if (items != null) {
                for (String itemId : items.getKeys(false)) {
                    ConfigurationSection is = items.getConfigurationSection(itemId);
                    if (is == null || !is.getBoolean("enabled", true)) continue;
                    Item item = parseItem(catId, itemId, is);
                    if (item != null) cat.items.add(item);
                }
            }
            categories.put(catId, cat);
        }
        loadSaved();
    }

    // ---------- предметы, добавленные командой /shop add ----------

    private File savedFile() {
        return new File(plugin.getDataFolder(), "saved-items.yml");
    }

    private void loadSaved() {
        File file = savedFile();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection cats = yml.getConfigurationSection("categories");
        if (cats == null) return;

        for (String catId : cats.getKeys(false)) {
            Category cat = categories.get(catId);
            ConfigurationSection items = cats.getConfigurationSection(catId + ".items");
            if (items == null) continue;
            if (cat == null) {
                plugin.getLogger().warning("saved-items.yml: категории '" + catId + "' нет в shop.yml, предметы пропущены.");
                continue;
            }
            for (String itemId : items.getKeys(false)) {
                ConfigurationSection is = items.getConfigurationSection(itemId);
                String encoded = is == null ? null : is.getString("item");
                if (encoded == null) continue;
                try {
                    ItemStack stack = ItemStack.deserializeBytes(Base64.getDecoder().decode(encoded));
                    cat.items.add(new Item(itemId, "", List.of(), stack.getType(), stack.getType(),
                            stack.getAmount(), Math.max(0, is.getDouble("price", 0)),
                            Map.of(), List.of(), true, stack, is.getDouble("sell-price", -1), "", null));
                } catch (Exception e) {
                    plugin.getLogger().warning("saved-items.yml: предмет " + catId + "." + itemId
                            + " не прочитан (" + e.getMessage() + ").");
                }
            }
        }
    }

    public Category category(String id) {
        return categories.get(id);
    }

    /** Сохраняет предмет в точности как он есть: зачарования, описание, данные других плагинов. */
    public String addSaved(String catId, String requestedId, ItemStack stack, double price, double sellPrice) {
        File file = savedFile();
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);

        String base = requestedId == null || requestedId.isBlank()
                ? stack.getType().name().toLowerCase(Locale.ROOT)
                : requestedId.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "");
        if (base.isEmpty()) base = "item";
        String id = base;
        int n = 2;
        while (yml.contains("categories." + catId + ".items." + id)) {
            id = base + "-" + n++;
        }

        String path = "categories." + catId + ".items." + id;
        yml.set(path + ".item", Base64.getEncoder().encodeToString(stack.serializeAsBytes()));
        yml.set(path + ".price", price);
        yml.set(path + ".sell-price", sellPrice);
        try {
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить saved-items.yml: " + e.getMessage());
            return null;
        }
        load();
        return id;
    }

    public boolean removeSaved(String catId, String id) {
        File file = savedFile();
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        String path = "categories." + catId + ".items." + id;
        if (!yml.contains(path)) return false;
        yml.set(path, null);
        try {
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить saved-items.yml: " + e.getMessage());
            return false;
        }
        load();
        return true;
    }

    private Item parseItem(String catId, String itemId, ConfigurationSection is) {
        String where = catId + "." + itemId;
        List<String> commands = is.getStringList("commands");
        boolean give = is.getBoolean("give-item", commands.isEmpty());
        Material material = material(is.getString("material", ""));
        Material icon = material(is.getString("icon", ""));

        if (give && material == null) {
            plugin.getLogger().warning("Предмет " + where + " пропущен: неверный material.");
            return null;
        }
        if (icon == null) icon = material != null ? material : Material.PAPER;

        Map<String, Integer> enchants = new LinkedHashMap<>();
        ConfigurationSection es = is.getConfigurationSection("enchants");
        if (es != null) {
            for (String key : es.getKeys(false)) {
                if (findEnchant(key) == null) {
                    plugin.getLogger().warning("Предмет " + where + ": зачарование '" + key + "' не найдено.");
                    continue;
                }
                enchants.put(key, es.getInt(key, 1));
            }
        }

        Item parsed = new Item(itemId, is.getString("name", ""), is.getStringList("lore"), material, icon,
                Math.max(1, is.getInt("amount", 1)), Math.max(0, is.getDouble("price", 0)),
                enchants, commands, give, null, is.getDouble("sell-price", -1),
                is.getString("display-name", ""), is.getString("potion-type"));
        parsed.maxQuantity = Math.max(0, is.getInt("max-quantity", 0));
        return parsed;
    }

    private static Material material(String name) {
        if (name == null || name.isBlank()) return null;
        return Material.matchMaterial(name.trim());
    }

    private static Enchantment findEnchant(String key) {
        String k = key.toLowerCase(Locale.ROOT);
        NamespacedKey nk = k.contains(":") ? NamespacedKey.fromString(k) : NamespacedKey.minecraft(k);
        return nk == null ? null : Registry.ENCHANTMENT.get(nk);
    }

    // ---------- предметы ----------

    public String priceText(double price) {
        VaultEconomy eco = plugin.economy();
        return eco == null ? String.valueOf(price) : eco.format(price);
    }

    /** display=true: иконка для меню (с ценой в описании), false: предмет, который получит игрок. */
    public ItemStack buildStack(Item item, boolean display) {
        if (item.template != null) {
            // Сохранённый предмет: отдаём копию как есть, в меню только добавляем цену.
            ItemStack copy = item.template.clone();
            if (display) {
                copy.setAmount(Math.max(1, Math.min(copy.getAmount(), copy.getMaxStackSize())));
                ItemMeta meta = copy.getItemMeta();
                if (meta != null) {
                    List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
                    lore.addAll(priceLines(item));
                    meta.lore(lore);
                    copy.setItemMeta(meta);
                }
            }
            return copy;
        }

        Material m = item.giveItem ? item.material : item.icon;
        int amount = display ? Math.min(item.amount, m.getMaxStackSize()) : item.amount;
        ItemStack stack = new ItemStack(m, Math.max(1, amount));

        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            // В меню показываем label (если есть), а игроку выдаём предмет только с настоящим именем name.
            String shown = display && !item.label.isEmpty() ? item.label : item.name;
            if (!shown.isEmpty()) meta.displayName(ShopPlugin.text(shown));
            List<Component> lore = new ArrayList<>();
            for (String line : item.lore) lore.add(ShopPlugin.text(line));
            if (display) lore.addAll(priceLines(item));
            if (!lore.isEmpty()) meta.lore(lore);
            if (item.potionType != null && meta instanceof PotionMeta potionMeta) {
                PotionType type = Registry.POTION.get(NamespacedKey.minecraft(item.potionType.toLowerCase(Locale.ROOT)));
                if (type != null) potionMeta.setBasePotionType(type);
            }
            stack.setItemMeta(meta);
        }

        if (!item.enchants.isEmpty()) {
            if (stack.getItemMeta() instanceof EnchantmentStorageMeta book) {
                // Зачарованная книга хранит зачарования отдельно, иначе их нельзя применить на наковальне.
                for (Map.Entry<String, Integer> e : item.enchants.entrySet()) {
                    Enchantment enchantment = findEnchant(e.getKey());
                    if (enchantment != null) book.addStoredEnchant(enchantment, e.getValue(), true);
                }
                stack.setItemMeta(book);
            } else {
                for (Map.Entry<String, Integer> e : item.enchants.entrySet()) {
                    Enchantment enchantment = findEnchant(e.getKey());
                    if (enchantment != null) stack.addUnsafeEnchantment(enchantment, e.getValue());
                }
            }
        }
        return stack;
    }

    private List<Component> priceLines(Item item) {
        List<Component> lines = new ArrayList<>();
        lines.add(Component.empty());
        lines.add(ShopPlugin.text(plugin.raw("price-lore").replace("%price%", priceText(item.price))));
        if (canSell(item)) {
            lines.add(ShopPlugin.text(plugin.raw("sell-lore").replace("%price%", priceText(item.sellPrice))));
        }
        return lines;
    }

    /**
     * Сколько порций можно выбрать за раз. Ограничение: max-quantity из config.yml, размер стака предмета
     * (нестакуемые предметы только по 1, с лимитом стака 16 не больше 16 штук) и личный max-quantity предмета.
     */
    public int maxQuantity(Item item) {
        int limit = Math.max(1, plugin.getConfig().getInt("max-quantity", 64));
        if (item.maxQuantity > 0) limit = Math.min(limit, item.maxQuantity);
        if (item.giveItem) {
            ItemStack stack = buildStack(item, false);
            int perPortion = Math.max(1, stack.getAmount());
            limit = Math.min(limit, Math.max(1, stack.getMaxStackSize() / perPortion));
        }
        return Math.max(1, limit);
    }

    /** Сколько штук можно продать за раз: только общий лимит из config.yml (размер стака не важен). */
    public int maxSellQuantity() {
        return Math.max(1, plugin.getConfig().getInt("max-quantity", 64));
    }

    // ---------- продажа ----------

    /** Продажа разрешена, если у предмета есть реальная выдача и цена продажи не отрицательная. */
    public boolean canSell(Item item) {
        return item.giveItem && item.sellPrice >= 0;
    }

    /** Один экземпляр предмета для сравнения с вещами игрока. */
    private ItemStack probe(Item item) {
        ItemStack probe = buildStack(item, false);
        probe.setAmount(1);
        return probe;
    }

    /** Сколько таких предметов лежит у игрока в инвентаре. */
    public int count(Player player, Item item) {
        ItemStack probe = probe(item);
        int total = 0;
        for (ItemStack slot : player.getInventory().getStorageContents()) {
            if (slot != null && slot.isSimilar(probe)) total += slot.getAmount();
        }
        return total;
    }

    /** Иконка для режима продажи: цена продажи, сколько есть у игрока и подсказки. */
    public ItemStack buildSellStack(Item item, Player player) {
        ItemStack stack = probe(item);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            if (!item.label.isEmpty() && item.name.isEmpty()) meta.displayName(ShopPlugin.text(item.label));
            List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
            lore.add(Component.empty());
            lore.add(ShopPlugin.text(plugin.raw("sell-lore").replace("%price%", priceText(item.sellPrice))));
            lore.add(ShopPlugin.text(plugin.raw("have-lore").replace("%count%", String.valueOf(count(player, item)))));
            lore.add(ShopPlugin.text(plugin.raw("sell-hint")));
            meta.lore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public boolean sell(Player player, Item item, boolean all) {
        return sell(player, item, all ? Integer.MAX_VALUE : 1);
    }

    /** Продать указанное количество штук (если у игрока меньше, продаётся всё, что есть). */
    public boolean sell(Player player, Item item, int wanted) {
        VaultEconomy eco = plugin.economy();
        if (eco == null) {
            player.sendMessage(plugin.msg("no-economy"));
            return false;
        }
        if (!canSell(item)) {
            player.sendMessage(plugin.msg("sell-disabled"));
            return false;
        }
        int have = count(player, item);
        if (have <= 0) {
            player.sendMessage(plugin.msg("nothing-to-sell"));
            return false;
        }
        int amount = Math.max(1, Math.min(wanted, have));
        double total = item.sellPrice * amount;
        if (!eco.deposit(player, total)) {
            player.sendMessage(plugin.msg("no-economy"));
            return false;
        }

        ItemStack probe = probe(item);
        org.bukkit.inventory.PlayerInventory inventory = player.getInventory();
        ItemStack[] contents = inventory.getStorageContents();
        int left = amount;
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack slot = contents[i];
            if (slot == null || !slot.isSimilar(probe)) continue;
            int take = Math.min(left, slot.getAmount());
            if (take == slot.getAmount()) {
                inventory.setItem(i, null);
            } else {
                ItemStack rest = slot.clone();
                rest.setAmount(slot.getAmount() - take);
                inventory.setItem(i, rest);
            }
            left -= take;
        }

        player.sendMessage(plugin.msg("sold", "%amount%", String.valueOf(amount),
                "%item%", item.displayName(), "%price%", priceText(total)));
        return true;
    }

    // ---------- покупка ----------

    public boolean buy(Player player, Item item) {
        return buy(player, item, 1);
    }

    /** Купить quantity порций (порция = то, что указано в amount предмета). */
    public boolean buy(Player player, Item item, int quantity) {
        quantity = Math.max(1, quantity);
        double total = item.price * quantity;
        VaultEconomy eco = plugin.economy();
        if (eco == null) {
            player.sendMessage(plugin.msg("no-economy"));
            return false;
        }

        ItemStack give = item.giveItem ? buildStack(item, false) : null;
        if (give != null) give.setAmount(Math.max(1, give.getAmount() * quantity));
        if (give != null && !hasSpace(player.getInventory(), give)) {
            player.sendMessage(plugin.msg("no-space"));
            return false;
        }
        if (!eco.has(player, total) || !eco.withdraw(player, total)) {
            player.sendMessage(plugin.msg("no-money", "%price%", priceText(total)));
            return false;
        }

        if (give != null) {
            for (ItemStack left : player.getInventory().addItem(give).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), left);
            }
        }
        for (int n = 0; n < quantity; n++) {
            for (String command : item.commands) {
                runCommand(player, command);
            }
        }

        String shownName = quantity > 1 ? quantity + "x " + item.displayName() : item.displayName();
        player.sendMessage(plugin.msg("bought", "%item%", shownName, "%price%", priceText(total)));
        return true;
    }

    /**
     * Запуск команды покупки. Без приставки команда идёт от консоли. Приставки:
     * [player] от имени игрока (нужны его права), [op] от имени игрока с временным op
     * (на время самой команды, потом op снимается), [console] от консоли.
     */
    private void runCommand(Player player, String raw) {
        String command = raw.trim().replace("%player%", player.getName());
        String lower = command.toLowerCase(Locale.ROOT);

        if (lower.startsWith("[player]")) {
            Bukkit.dispatchCommand(player, stripSlash(command.substring(8)));
        } else if (lower.startsWith("[op]")) {
            boolean wasOp = player.isOp();
            try {
                if (!wasOp) player.setOp(true);
                Bukkit.dispatchCommand(player, stripSlash(command.substring(4)));
            } finally {
                if (!wasOp) player.setOp(false);
            }
        } else if (lower.startsWith("[console]")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), stripSlash(command.substring(9)));
        } else {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), stripSlash(command));
        }
    }

    private static String stripSlash(String command) {
        String c = command.trim();
        return c.startsWith("/") ? c.substring(1) : c;
    }

    private static boolean hasSpace(Inventory inventory, ItemStack stack) {
        int need = stack.getAmount();
        for (ItemStack slot : inventory.getStorageContents()) {
            if (slot == null || slot.getType().isAir()) {
                need -= stack.getMaxStackSize();
            } else if (slot.isSimilar(stack)) {
                need -= Math.max(0, slot.getMaxStackSize() - slot.getAmount());
            }
            if (need <= 0) return true;
        }
        return false;
    }
}
