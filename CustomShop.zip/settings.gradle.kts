rootProject.name = "CustomShop"
