package me.customshop;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.lang.reflect.Method;

/**
 * Обёртка над Vault/VaultUnlocked через рефлексию, чтобы сборке не нужна была
 * библиотека Vault. Работает с любой экономикой, которая зарегистрирована в Vault (например Essentials).
 */
final class VaultEconomy {

    private final Object provider;
    private final Method getBalance;
    private final Method withdraw;
    private final Method depositMethod;
    private final Method format;

    private VaultEconomy(Object provider, Class<?> cls) throws NoSuchMethodException {
        this.provider = provider;
        this.getBalance = cls.getMethod("getBalance", OfflinePlayer.class);
        this.withdraw = cls.getMethod("withdrawPlayer", OfflinePlayer.class, double.class);
        this.depositMethod = cls.getMethod("depositPlayer", OfflinePlayer.class, double.class);
        this.format = cls.getMethod("format", double.class);
    }

    static VaultEconomy hook() {
        try {
            Plugin vault = Bukkit.getPluginManager().getPlugin("Vault");
            if (vault == null) return null;
            Class<?> cls = Class.forName("net.milkbowl.vault.economy.Economy", true, vault.getClass().getClassLoader());
            RegisteredServiceProvider<?> rsp = Bukkit.getServicesManager().getRegistration(cls);
            if (rsp == null) return null;
            return new VaultEconomy(rsp.getProvider(), cls);
        } catch (Throwable t) {
            return null;
        }
    }

    double balance(OfflinePlayer player) {
        try {
            return ((Number) getBalance.invoke(provider, player)).doubleValue();
        } catch (Exception e) {
            return 0;
        }
    }

    boolean has(OfflinePlayer player, double amount) {
        return balance(player) + 1e-9 >= amount;
    }

    boolean withdraw(OfflinePlayer player, double amount) {
        if (amount <= 0) return true;
        try {
            Object response = withdraw.invoke(provider, player, amount);
            return (boolean) response.getClass().getMethod("transactionSuccess").invoke(response);
        } catch (Exception e) {
            return false;
        }
    }

    boolean deposit(OfflinePlayer player, double amount) {
        if (amount <= 0) return true;
        try {
            Object response = depositMethod.invoke(provider, player, amount);
            return (boolean) response.getClass().getMethod("transactionSuccess").invoke(response);
        } catch (Exception e) {
            return false;
        }
    }

    String format(double amount) {
        try {
            return String.valueOf(format.invoke(provider, amount));
        } catch (Exception e) {
            return String.valueOf(amount);
        }
    }
}
