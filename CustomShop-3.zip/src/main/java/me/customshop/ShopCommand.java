package me.customshop;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class ShopCommand implements TabExecutor {

    private final ShopPlugin plugin;

    public ShopCommand(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "";

        if (sub.equals("reload") || sub.equals("add") || sub.equals("remove") || sub.equals("update")) {
            if (!sender.hasPermission("customshop.admin")) {
                sender.sendMessage(plugin.msg("no-permission"));
                return true;
            }
            switch (sub) {
                case "reload" -> {
                    plugin.reloadAll();
                    sender.sendMessage(plugin.msg("reloaded"));
                }
                case "update" -> update(sender);
                case "add" -> add(sender, args);
                default -> remove(sender, args);
            }
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("players-only"));
            return true;
        }

        if (sub.equals("mode")) {
            plugin.toggleMode(player);
        } else {
            plugin.open(player);
        }
        return true;
    }

    /** /shop add <категория> <цена> [id]: берёт предмет из руки и сохраняет его как есть. */
    private void add(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("players-only"));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(plugin.msg("add-usage"));
            return;
        }
        ShopManager.Category category = plugin.shop().category(args[1]);
        if (category == null) {
            sender.sendMessage(plugin.msg("category-missing", "%list%", categoryList()));
            return;
        }
        Double price = number(args[2]);
        if (price == null || price < 0) {
            sender.sendMessage(plugin.msg("bad-price"));
            return;
        }
        // Необязательные аргументы: цена продажи (число; отрицательное = продажа запрещена) и id.
        double sellPrice = -1;
        int next = 3;
        if (args.length > next) {
            Double parsed = number(args[next]);
            if (parsed != null) {
                sellPrice = parsed;
                next++;
            }
        }
        String requestedId = args.length > next ? args[next] : null;

        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            sender.sendMessage(plugin.msg("no-item-in-hand"));
            return;
        }
        String id = plugin.shop().addSaved(category.id, requestedId, hand, price, sellPrice);
        if (id == null) return;
        sender.sendMessage(plugin.msg("item-added", "%category%", category.id, "%id%", id));
    }

    /** /shop remove <категория> <id>: удаляет предмет, добавленный через /shop add. */
    private void remove(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(plugin.msg("remove-usage"));
            return;
        }
        if (plugin.shop().removeSaved(args[1], args[2])) {
            sender.sendMessage(plugin.msg("item-removed", "%category%", args[1], "%id%", args[2]));
        } else {
            sender.sendMessage(plugin.msg("item-not-found"));
        }
    }

    /**
     * /shop update: скачивает свежую сборку по update-url из config.yml в папку plugins/update.
     * Сервер сам заменит старый jar на новый при следующем перезапуске.
     */
    private void update(CommandSender sender) {
        String url = plugin.getConfig().getString("update-url", "");
        if (url.isBlank()) {
            sender.sendMessage(plugin.msg("update-no-url"));
            return;
        }
        sender.sendMessage(plugin.msg("update-start"));

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            String error = null;
            try {
                HttpClient client = HttpClient.newBuilder()
                        .followRedirects(HttpClient.Redirect.ALWAYS)
                        .connectTimeout(Duration.ofSeconds(15))
                        .build();
                HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                        .timeout(Duration.ofSeconds(90))
                        .header("User-Agent", "CustomShop-Updater")
                        .GET()
                        .build();
                HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
                byte[] body = response.body();

                if (response.statusCode() != 200) {
                    error = "ответ сервера " + response.statusCode();
                } else if (body.length < 1000 || body[0] != 'P' || body[1] != 'K') {
                    error = "скачан не jar-файл";
                } else {
                    File dir = Bukkit.getUpdateFolderFile();
                    Files.createDirectories(dir.toPath());
                    Files.write(new File(dir, plugin.jarName()).toPath(), body);
                }
            } catch (Exception e) {
                error = e.getClass().getSimpleName() + ": " + e.getMessage();
            }

            String failure = error;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (failure == null) {
                    sender.sendMessage(plugin.msg("update-done"));
                } else {
                    sender.sendMessage(plugin.msg("update-failed", "%error%", failure));
                }
            });
        });
    }

    private static Double number(String text) {
        try {
            double value = Double.parseDouble(text.replace(',', '.'));
            return Double.isNaN(value) || Double.isInfinite(value) ? null : value;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String categoryList() {
        return plugin.shop().categories().stream()
                .map(c -> c.id)
                .collect(Collectors.joining(", "));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        boolean admin = sender.hasPermission("customshop.admin");
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);

        if (args.length == 1) {
            List<String> options = new ArrayList<>(List.of("mode"));
            if (admin) options.addAll(List.of("reload", "add", "remove", "update"));
            return options.stream().filter(s -> s.startsWith(last)).toList();
        }
        if (admin && args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("remove"))) {
            return plugin.shop().categories().stream()
                    .map(c -> c.id)
                    .filter(s -> s.toLowerCase(Locale.ROOT).startsWith(last))
                    .toList();
        }
        return List.of();
    }
}
