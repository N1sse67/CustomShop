package me.customshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;

public final class ShopPlugin extends JavaPlugin {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private ShopManager shop;
    private VaultEconomy economy;
    private BedrockHook bedrock;
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        shop = new ShopManager(this);
        shop.load();
        loadData();

        getServer().getPluginManager().registerEvents(new ShopListener(), this);

        ShopCommand handler = new ShopCommand(this);
        PluginCommand command = getCommand("shop");
        if (command != null) {
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }
        getLogger().info("CustomShop включён. Категорий: " + shop.categories().size());
    }

    public void reloadAll() {
        reloadConfig();
        shop.load();
        loadData();
    }

    // ---------- данные игроков (выбранный вид магазина) ----------

    private void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().warning("Не удалось сохранить data.yml: " + e.getMessage());
        }
    }

    /** Имя jar-файла этого плагина в папке plugins (нужно для папки plugins/update). */
    public String jarName() {
        return getFile().getName();
    }

    // ---------- доступ к частям ----------

    public ShopManager shop() {
        return shop;
    }

    /** Экономика ищется лениво: плагины экономики могут включиться позже нас. */
    public VaultEconomy economy() {
        if (economy == null) economy = VaultEconomy.hook();
        return economy;
    }

    public BedrockHook bedrock() {
        if (bedrock == null && getServer().getPluginManager().isPluginEnabled("floodgate")) {
            try {
                bedrock = new BedrockHook(this);
            } catch (Throwable t) {
                getLogger().warning("Floodgate найден, но подключиться не удалось: " + t);
            }
        }
        return bedrock;
    }

    // ---------- тексты ----------

    public String raw(String key) {
        return getConfig().getString("messages." + key, key);
    }

    public Component msg(String key, String... replacements) {
        String text = raw(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            text = text.replace(replacements[i], replacements[i + 1]);
        }
        return LEGACY.deserialize(raw("prefix") + text);
    }

    /** Текст для предметов: без курсива, который Minecraft ставит по умолчанию. */
    public static Component text(String legacy) {
        return LEGACY.deserialize(legacy).decoration(TextDecoration.ITALIC, false);
    }

    public static Component title(String legacy) {
        return LEGACY.deserialize(legacy);
    }

    public String balanceText(Player player, String key) {
        VaultEconomy eco = economy();
        String balance = eco == null ? "?" : eco.format(eco.balance(player));
        return raw(key).replace("%balance%", balance);
    }

    // ---------- вид магазина ----------

    public boolean isBedrock(Player player) {
        BedrockHook hook = bedrock();
        return hook != null && hook.isBedrock(player.getUniqueId());
    }

    public boolean useForm(Player player) {
        if (!isBedrock(player)) return false;
        boolean def = !"chest".equalsIgnoreCase(getConfig().getString("bedrock-default", "form"));
        return data.getBoolean("form-mode." + player.getUniqueId(), def);
    }

    public void toggleMode(Player player) {
        if (!isBedrock(player)) {
            player.sendMessage(msg("mode-bedrock-only"));
            return;
        }
        boolean now = !useForm(player);
        data.set("form-mode." + player.getUniqueId(), now);
        saveData();
        player.sendMessage(msg(now ? "mode-form" : "mode-chest"));
        player.closeInventory();
        Bukkit.getScheduler().runTask(this, () -> open(player));
    }

    public void open(Player player) {
        if (useForm(player)) {
            bedrock().openMain(player);
        } else {
            ShopMenu.openMain(this, player);
        }
    }
}
